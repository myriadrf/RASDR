On your RASDR CD, you will find a 'RASDR-authority.cer' file.

Before you plug-in your RASDR board, please access this file and use the Windows explorer to right-click the file.
On the menu, you will see an 'Install Certificate' option.  Please follow the instructions to install the certificate to the 'Trusted Root Certification Authorities' store.

Please double-click the 'RASDR-authority.cer' file, and press 'Install Certificate'.  You will be asked to choose 'Current User' or 'Local Machine'.  Choose 'Local Machine' (rasdr-win81-install-certificate-1.png).  You will be asked to provide an administrator password.  After you do that, it will ask where to put the certificate, please choose 'Trusted Root Certification Authorities' by browsing (rasdr-win81-install-certificate-2.png).  When this process completes, you should be able to re-open the 'RASDR-authority.cer' file and it should show that the certificate is trusted as shown in (rasdr-authority-certificate.png).

The above procedure was tested with Windows 8.1.  It should be similar or identical on Windows 7 and Windows XP.  The only consideration is to ensure that the procedure is run as an Administrator.  If you are using an account that does not have administration priveleges (Least User Priveledge), then you must switch user to a full Administrator account in order to load the 'RASDR-authority.cer' certificate file using the above.  You may be presented with a dialog similar to 'rasdr-win7-install-certificate-3.png'.  It seems the thumbprints differ from different systems using the same certificate, this is not fully understood yet.  Once that is done, you can log out and resume loading the driver under your user account.

If you have done the above steps correctly, you should be able to double-click the 'RASDR-authority.cer' file under your user account and see a screen similar to 'rasdr-authority-certificate.png'.

After this is done, please connect your RASDR to the USB, and point the new device manager to the location on the CD containing the driver files:

d:\driver\

You will then see some screenshots as shown in the included files: rasdr-win81-accept-driver.png, rasdr-win81-driver-details.png or win7-details.png, rasdr-installed.png.  When you run the cypress CyControl, you should see the following information 'cypress-usb-control.png'

NOTE: On Windows 7 64-bit, it still gave me a warning about not being able to verify the driver signature, but it accepted to load the driver.

At this point, your system is ready to run 'RASDRviewer_W.exe' or 'RASDRproc_d.exe'
