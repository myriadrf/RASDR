RASDRviewer_W_1_2_2_1 Release 8 May 2015

This folder contains the release of RASDRviewer_W 1.2.2.1

This is a Windows release however it will run using Boot Camp on a MAC OS-X machine. It has been tested only with the Cypress Driver due to
the incompatability of the RASDR driver with Windows 8.1.

This release allows the use of either the SARA firmware image files. It is issued as a minor
feature addition. The following features were added in this release:

1. Fractional Values on the RF Freq saved value. 4 place fractional parts are now available.
2. The label on the RF freqeuncy was changed to RF CTR Freq.
3. The number of fractional digits on the fFT output was changed to provide more significant digits.
4. A running tally window was added to count the number of records placed on the FFT output file.
5. A Max Hold Feature was added to the FFT chart screen. The user can toggle between Max Hold and current FFT output data. 
If Max Hold is operating, the data saved to the disk will also be the Max Hold values.
6. The maximum number of FFTs in the average was increased to 128. This is the maximum without extensive DATA Structure changes.
7. The Power Chart scaling was improved.
8. The Power Chart Values were changed to show microwatts instead of miliwatts. A new scaling factor was used.
9. A user aid was added for the setting of levels in the system. When the level is adequate, the power chart line will be green.
When it is to high or to low, the chart line will be red. For the proper setting of gain, the user should find a dark sky position for 
pointing the dish and bring the gains up to a point where the chartline turns green.


The releasse has been tested on Windows 7 X64, and it should run (untested) on a MAC OS Mavericks with
a boot camp loaded with Windows 8.1 X64. It will also run on a Windows XP earlier version system with NIVIDIA graphics
card. It will not work on earlier (prior to 2006) that use the Intel chip set for the graphics display. When the program attempts
to load on these early systems, it fails due to the incompatability with Open GL charting that is used in the program. Some of
these systems may work with the retrofit of a NIVIDIA graphics card. The driver for the NIVIDIA card needs to be the latest available
from NIVIDIA. It will not work with the latest Microsoft Driver for the NIVIDIA card. It is necessary to disable the automatic Miscrosoft
driver update to avoid the installation of the earlier Microsoft driver.

This release is based on RASDRviewer_W 1.2.1.0 and should include all previous releases and patches.

To install the release on a Windows machine:
1. Open the file RASDRviewer_1_2_2_1_W_exe zip with WinZip or equivalent.
2. Extract all of the files in the zip folder to a folder of your choice. (i.e. c:\RASDRviewer)
3. Create a shortcut to the executable in the folder ReleaseWin32, drag or copy the shortcut to your desktop.
4. Execute the program by double clicking the shortcut.

System Requirements:

1. Windows (2000 or Later) X86 capable machine. Sincle Core machines will work but a dual(or larger) core system is recommended.
2. Lime Microsystems/Myriad RF - Digi-Red board with Myriad RF board
3. USB 2 or USB 3 port (USB3 (untested) is preferred but to obtain maximum performance)
4. SARA "RASDR Radio Astronomy SDR Rx Interface" driver. The SARA driver will not work on Windows 8. 
The Cypress Streamer Example driver will likely work on Windows 8.


Known Issues :  The author experienced several closing issues during testing. These all show the symptom of a frozen screen with partial
objects present when closing the application. The issues found all related to the sequence of events in closing with various
power chart options (integration time, display size) and power record data options. Some were noticed and fixed that related to whether 
the user was still recording data at the time of the close. Others related to different options on the number of records to save. If you
you encounter other issues related to closing, you can force a close by using "Task Manager" on Windows. Please promptly report any
issues to the author.

Features Held for future releases: 
1. The Marker has the wrong scale.
2. More complete Header data.
3. The inclusion of the Span in the saved configuration file. This will require a lot of thought as to whether to use the last
session value when the user has changed other parameters such as bandwidth or sample rate. For now, the Span and Center on the
FFT chart always initially matches the setup for bandwidth and sample rate. The user can change it if needed. The values are not
saved in the configuration file for future use.

Report any additional isssues to Paul Oxley 770-887-3493 oxleys@att.net

Your RASDR Team