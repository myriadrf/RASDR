On your RASDR CD, you will find a 'RASDR-authority.cer' file.

Before you plug-in your RASDR board, please access this file and use the Windows explorer to right-click the file.
On the menu, you will see an 'Install Certificate' option.  Please follow the instructions to install the certificate to the 'Trusted Root Certification Authorities' store.

On Windows 8(.1) please double-click the 'RASDR-authority.cer' file, and press 'Install Certificate'.  You will be asked to choose 'Current User' or 'Local Machine'.  Choose 'Local Machine' (rasdr-win81-install-certificate-1.png).  You will be asked to provide an administrator password.  After you do that, it will ask where to put the certificate, please choose 'Trusted Root Certification Authorities' by browsing (rasdr-win81-install-certificate-2.png).  When this process completes, you should be able to re-open the 'RASDR-authority.cer' file and it should show that the certificate is trusted as shown in (rasdr-authority-certificate.png).

On Windows 7 you must run the 'certmgr.exe' program as an administrator.  Then, choose 'Trusted Root Certificate Authority' and under it 'Certificates'.  After this, choose 'Action->Import' and ensure that the Certificate import Wizard sets 'Place all certificates in the following store' with 'Trusted Root Certification Authorities' as the certificate store.  Afterward you will get a message as shown in 'certmgr-import-4.png'.  Press yes.  

Afterward, you should see this 'rasdr-authority-certificate.png' if you double-click the 'RASDR-authority.cer' file.

After this is done, please connect your RASDR to the USB, and point the new device manager to the location on the CD containing the driver files:

d:\driver\

You will then see some screenshots as shown in the included files: rasdr-win81-accept-driver.png, rasdr-win81-driver-details.png or win7-details.png, rasdr-installed.png.  When you run the cypress cy control, you should see the following information 'cypress-usb-control.png'

NOTE: On Windows 7 64-bit, it still gave me a warning about not being able to verify the driver signature, but it accepted to load the driver.

At this point, your system is ready to run 'RASDRviewer_W.exe' or 'RASDRproc_d.exe'
