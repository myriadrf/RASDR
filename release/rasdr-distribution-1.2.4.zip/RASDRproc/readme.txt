RASDRproc v0.2.2.1 - Jun 28, 2016
=================================

RASDRproc.exe is the open-source version of the RASDR device setup and data collection program
RASDRproc_d.exe is a debug version that opens a DOS console which writes diagnostic data out

The program is able to configure RASDR2 and RASDR3 devices, set sample rates and receiver parameters.  It can optionally also display received data in time and frequency domain, I vs Q and total power.  Data collected may be saved to ASCII output files for further analysis and post-processing.


System Requirements:

1. Windows (XP or later) machine.  Dual core machines will work but a quad (or larger) core system is recommended.
2. Lime Microsystems/Myriad RF - DigiRed board with Myriad RF board ("RASDR2").
3. USB 2 or USB 3 port.
4. SARA "RASDR Radio Astronomy SDR Rx Interface" driver.


Usage:

Connect a RASDR2 device to the USB port of your computer (see the RASDR user manual for details on assigning the driver).  Double-click either RASDRproc or RASDRproc_d and wait for it to configure the device.  If you see non-zero values for "chip: rev: mask:" in the lower-left corner of the screen, it has connected to the RASDR device successfully.  Otherwise, you may still use the GUI functions to setup the configuration file.

At this point, you may press 'Start Acquisition' and observe the data collection.

When you close the program, the last set of parameters used will be written to the "RASDR.cfg" file for use next time.  RASDRproc produces annotated configuration files whose settings are described in the file itself.  It is compatible with the (un-annotated) ASCII configuration files used by RASDRviewer 1.2.2.2 and BELOW.


DC Offset Correction:

RASDRproc uses *MANUAL* DC Offset Correction.  The calibration procedure is as follows:

1) Setup the desired acquisition parameters and start data collection.  While collecting data, connect a 50ohm load to the RX of the receiver.

2) From the 'Performance Parameters' menu, select 'Tuning Parameters'.  This brings up a pop-up window where an I and Q offset is able to be entered.  While data is being collected, press the 'Use Current Averages' and observe that the values are updated. Then, press 'OK Accept Values' and see that the DC offset correction is applied.

The calibration values are saved along with the other parameters in the RASDR.cfg file.

If necessary, repeat the above procedure to compute new offsets.  Typically, it has not been seen that the offset needs to be corrected continuously, but the offset IS different each time the RASDR2 device is powered up and it does depend on what antenna system and front end electronics are connected to the RASDR RX port, as well as the sampling rate and gain settings.


Auto Restart:

RASDR2 devices when used in USB3 on marginal machines exhibit a stall acquiring data.  It has been shown that if data acquisition is stopped, then started dataflow may recover (but not always).  In those cases, the driver must be closed and re-opened, and then dataflow recovers.  This version of RASDRproc implements a detection and mitigation for this condition.  It is enabled by checking the 'Auto Restart' tick box in the upper right corner near the frame rate display.

In addition, this version annotates the data rate and frame rate display with a comparision to the expected rates and uses a RED or YELLOW background if the program is not keeping up.  The thresholds are fixed at compile time at the moment.


Known Issues:

1) The program will give an ugly dialog box if it cannot find its settings file 'RASDR.cfg', but will create a new one when the program exits.

2) When using USB 3 on a marginal machine (e.g. dual core, 4GB RAM) the application is known to stop acquiring data.  With the updated Cypress WHQL driver, this condition can be cleared by manually stopping then restarting acquisition.  It is not yet understood why this occurs.  This behavior has not been observed on a more robust machine (e.g. quad core, 8GB RAM).  The working theory at this point is that RASDRviewer/RASDRproc and its use of the Cypress driver API requires two cores to itself and OS activity can interfere with the timing of completion requests for USB buffers.

One very strong driver of this condtion was the use of burst mode transfer for USB3 super speed.  When the burst length is set to 1, the effect it has on a lower spec machine is dramatic.  Unfortunately, it was not the only thing needed, and in some rare cases a glitch was still observed to occur.  For this reason, a workaround was found to allow data to keep being collected.

3) Scaling of the frequency plot, the use of markers and other aspects of the UI can produce unsatisfactory results.  Please be persistent in your efforts to make the plot look they way you want it.  RASDRproc v0.2.2.1 has for all intents and purposes solved the issues with the Power Plot.  Please let us know if you find a behavior that is unsatisfactory.

4) "RASDRproc.exe", if started w/o a RASDR device connection may take a very long time to start.  This does not seem to be the case with "RASDRproc_d.exe"

5) Sometimes when restarting (or if Auto Restart) is enabled, the program will raise an exception in the CCyUSBEndPoint::FinishDataXfer() as it deletes buffers.  This is when the stop is initiated by a call to LMLL_Testing_StopSdramRead() to stop collecting data from the USB stream.

Debugging this has not illuminated a good explanation for this behavior.
