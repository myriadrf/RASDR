RASDRviewer_W_1_2_2_2 Release 29 Jul 2015

This folder contains the release of RASDRviewer_W 1.2.2.2

This is a Windows release.

This release allows the use of either the SARA firmware image files. It is issued as a minor
feature addition. The following features were added in this release:

1. Bug fix in .csv ASCII output routine.
2. Tested with updated Cypress WHQL driver that supports windows 8.

The release has been tested on Windows 7 X64, and it should run (untested) on a MAC OS Mavericks with
a boot camp loaded with Windows 8.1 X64. It will also run on a Windows XP earlier version system with NIVIDIA graphics
card. It will not work on earlier (prior to 2006) that use the Intel chip set for the graphics display. When the program attempts
to load on these early systems, it fails due to the incompatability with Open GL charting that is used in the program. Some of
these systems may work with the retrofit of an NVIDIA graphics card. The driver for the NVIDIA card needs to be the latest available
from NVIDIA. It will not work with the latest Microsoft Driver for the NVIDIA card. It is necessary to disable the automatic Microsoft
driver update to avoid the installation of the Microsoft driver.

This release is based on RASDRviewer_W 1.2.1.1 and should include all previous releases and patches.

To install the release on a Windows machine:
1. Open the file RASDRviewer_1_2_2_2W.zip with WinZip or equivalent.
2. Extract all of the files in the zip folder to a folder of your choice. (i.e. c:\RASDRviewer)
3. Create a shortcut to the executable in the folder ReleaseWin32, drag or copy the shortcut to your desktop.
4. Execute the program by double clicking the shortcut.

System Requirements:

1. Windows (XP or Later) machine. Dual core machines will work but a quad(or larger) core system is recommended.
2. Lime Microsystems/Myriad RF - Digi-Red board with Myriad RF board.
3. USB 2 or USB 3 port.
4. SARA "RASDR Radio Astronomy SDR Rx Interface" driver.

Known Issues:

When using USB 3 on a marginal machine (e.g. dual core, 4GB RAM) the application is known to stop acquiring data.  With the updated Cypress WHQL driver, this condition can be cleared by manually stopping then restarting acquisition.  It is not yet understood why this occurs.  This behavior has not been observed on a more robust machine (e.g. quad core, 8GB RAM).  The working theory at this point is that RASDRviewer and its use of the Cypress driver API requires two cores to itself and OS activity can interfere with the timing.  This condition will be corrected as soon as the root cause is determined.

[from RASDRviewer 1.2.2.1] The author experienced several closing issues during testing. These all show the symptom of a frozen screen with partial
objects present when closing the application. The issues found all related to the sequence of events in closing with various
power chart options (integration time, display size) and power record data options. Some were noticed and fixed that related to whether 
the user was still recording data at the time of the close. Others related to different options on the number of records to save. If you
you encounter other issues related to closing, you can force a close by using "Task Manager" on Windows. Please promptly report any
issues to the author.

Features Held for future releases: 
1. The Marker has the wrong scale.
2. More complete Header data.
3. The inclusion of the Span in the saved configuration file. This will require a lot of thought as to whether to use the last
session value when the user has changed other parameters such as bandwidth or sample rate. For now, the Span and Center on the
FFT chart always initially matches the setup for bandwidth and sample rate. The user can change it if needed. The values are not
saved in the configuration file for future use.
4. Windows 10 support/verification.

Report any additional isssues to Paul Oxley 770-887-3493 oxleys@att.net

Your RASDR Team