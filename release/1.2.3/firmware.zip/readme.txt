RASDR - DigiRED+MyriadRF Receive Port Firmware - Release 1.1 - Jul 22, 2015
===========================================================================

error-codes.txt		- Blink codes for firmware error reporting
license.txt		- Cypress Semiconductor License Agreement
readme.txt		- This file
usb_rx.img		- Firmware binary to be loaded to DigiRED board

This firmware was built using the Cypress EZ-USB SDK (*) v1.3.3 which provides WHQL drivers for Windows 8.1, 8 as well as 7 and XP, both 32-bit and 64-bit variants.

You may use the Cypress USB Control application provided in the EZ-USB SDK to update the firmware on the RASDR USB3 Interface Board.

The RASDR project gratefully acknowledges Cypress Semiconductor Corporation for enabling the development of the RASDR Firmware and Windows Support.  These files and the source code (../src/usb_rx.zip) are derivative works distributed with permission under Case #2427983098.

(*) Please see http://www.cypress.com/?rid=57990