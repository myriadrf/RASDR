RASDR - DigiRED+MyriadRF Receive Port Firmware - Release 1.0 - Feb 17, 2014
===========================================================================

error-codes.txt		- Blink codes for firmware error reporting
license.txt		- Cypress Semiconductor License Agreement
readme.txt		- This file
usb_rx.img		- Firmware binary to be loaded to DigiRED board

You may use the Cypress USB Control application provided in the EZ-USB SDK
to update the firmware on the RASDR USB3 Interface Board.

The RASDR project gratefully acknowledges Cypress Semiconductor Corporation for enabling the development of the RASDR Firmware and Windows Support (*).  These files and the source code (https://github.com/myriadrf/RASDR/tree/master/DigiRED/firmware/src/usb_rx.zip) are derivative works distributed with permission under Case #2427983098.

(*) Please see http://www.cypress.com/?rid=57990